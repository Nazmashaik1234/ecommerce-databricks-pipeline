
# Bronze Layer
df_orders = spark.read.csv("/FileStore/ecommerce/orders.csv", header=True, inferSchema=True)
df_orders.write.format("delta").mode("overwrite").saveAsTable("bronze_orders")

# Silver Layer
orders = spark.table("bronze_orders")
customers = spark.table("bronze_customers")
products = spark.table("bronze_products")

silver_df = orders.join(customers, "customer_id").join(products, "product_id").dropna()
silver_df.write.format("delta").mode("overwrite").saveAsTable("silver_ecommerce")

# Gold Layer
spark.sql("""
CREATE OR REPLACE TABLE gold_sales AS
SELECT category, SUM(amount) AS total_sales, COUNT(order_id) AS total_orders
FROM silver_ecommerce
GROUP BY category
""")
